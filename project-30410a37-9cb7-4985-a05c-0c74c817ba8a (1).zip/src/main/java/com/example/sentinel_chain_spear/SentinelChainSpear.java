package com.example.sentinel_chain_spear;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod("sentinel_chain_spear")
public class SentinelChainSpear {
    public SentinelChainSpear(IEventBus eventBus) {
        eventBus.addListener(this::setup);
    }

    private void setup(final FMLCommonSetupEvent event) {
        ModRegistry.register(eventBus);
        NeoForge.EVENT_BUS.register(new AbilityEventHandler());
    }
}