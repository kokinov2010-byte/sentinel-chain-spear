package com.example.sentinel_chain_spear.registry;

import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import com.example.sentinel_chain_spear.item.SentinelChainSpearItem;

public class ModRegistry {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sentinel_chain_spear");
    
    public static final Item SENTINEL_CHAIN_SPEAR = ITEMS.register("sentinel_chain_spear", SentinelChainSpearItem::new);
    
    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}