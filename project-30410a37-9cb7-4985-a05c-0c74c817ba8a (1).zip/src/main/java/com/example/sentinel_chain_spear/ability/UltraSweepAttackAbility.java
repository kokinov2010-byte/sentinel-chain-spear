package com.example.sentinel_chain_spear.ability;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class UltraSweepAttackAbility {
    public static void activate(Player player, Level level) {
        // Ability logic here
    }
}