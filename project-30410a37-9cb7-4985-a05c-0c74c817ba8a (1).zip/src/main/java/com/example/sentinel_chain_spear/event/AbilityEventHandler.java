package com.example.sentinel_chain_spear.event;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import com.example.sentinel_chain_spear.ability.ChainThrowPullAbility;
import com.example.sentinel_chain_spear.ability.UltraSweepAttackAbility;

public class AbilityEventHandler {
    @SubscribeEvent
    public void onPlayerInteract(PlayerInteractEvent.RightClickItem event) {
        // Event handling logic here
    }
}