package com.example.sentinel_chain_spear.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;

public class SentinelChainSpearItem extends SwordItem {
    public SentinelChainSpearItem() {
        super(Tier.DIAMOND, 36, 1.4f, new Item.Properties());
    }
}